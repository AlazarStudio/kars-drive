export { default } from 'expo-router/entry';
