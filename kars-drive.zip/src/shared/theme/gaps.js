export const gaps = {
    g14: 14,
    g22: 22
};
