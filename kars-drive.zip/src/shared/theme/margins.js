export const margins = {
    m14: 14,
    
    mb4: 4,
    mb6: 6,
    mb20: 20,
    mb40: 40
};
