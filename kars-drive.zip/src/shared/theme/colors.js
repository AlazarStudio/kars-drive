export const colors = {
    background: '#285FE5',
    text: '#000000',
    grayBackground: '#F2F2F7',
    grayText: '#999999',
    white: '#ffffff',
    link: '#2F7ACC'
  };
  