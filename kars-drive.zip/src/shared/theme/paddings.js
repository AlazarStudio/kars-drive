export const paddings = {
    p14: 14,
    p16: 16,
    p20: 20,
    p24: 24,

    pl11: 11
};
