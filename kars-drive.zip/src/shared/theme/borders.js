export const borders = {
    br10: 10,
    br20: 20
};
