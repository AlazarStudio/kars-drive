export const fonts = {
    fs12: 12,
    fs16: 16,
    fs17: 17,
    fs21: 21,

    fw500: 500,
    fw600: 600,
    fw700: 700,
};
