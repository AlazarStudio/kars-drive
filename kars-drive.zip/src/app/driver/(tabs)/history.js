// app/driver/(tabs)/history.js
import { View, Text } from 'react-native';

export default function HistoryScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>История</Text>
    </View>
  );
}
