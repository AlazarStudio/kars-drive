// app/driver/(tabs)/support.js
import { View, Text } from 'react-native';

export default function SupportScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Поддержка</Text>
    </View>
  );
}
